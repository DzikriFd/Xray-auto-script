# Patch List

# 19-09-2022
- Core Updated to (1.6.0)
- All Depedencies Updated
- Fix sumting wong
# 15-09-2022
- Bring Back Routing Cloudflare ( Trojan WS Only)
- Fix issue Ipv6 . Force Ipv4 Avoid Miss Database IP
- Core updated to (1.5.10)
# 06-09-2022
- Add Backup & Restore (Powered by Github)
- Custom Kernel (Powered By XanMod Kernel)
- Fix missing pkg
- Fix cert ajsjdhjhdjakhf
- Misc
- Traffic ? (Knownbugs no have idea for next implements this)
# 17-08-2022
- Add Shadowsocks AEAD (chacha20-ietf-poly1305)
- Removed unused code
- Updates Menu
- Core changed to Prarelease (1.5.9)
- Traffic Menu (Knownbugs no have idea for implements this)
# 11-08-2022
- gRPC header set
# 04-08-2022
- Fix %26 Misscode & Failed Import VLESS
# 26-07-2022
- No more using cloudflare ! (Cause Delay)
# 17-07-2022
- Fix Trojan Not Correct Import Format
# 16-07-2022
- Initial Release